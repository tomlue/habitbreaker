# HabitBreaker Chrome Extension

Adds delay screns and other tactics to improve human productivity.
